# 💙 WizyBoo

**Your Windows troubleshooting companion.**

Welcome to WizyBoo! WizyBoo is a Windows troubleshooting application designed to help users troubleshoot older programs and Windows Live Messenger (WLM) issues.

## 💻 Compatibility

- Windows 7
- Windows 8
- Windows 8.1

## ⚙️ Architecture

- x86 (32-bit)
- x64 (64-bit)

## 📦 Installer

**Filename:** `wybsetup.msi`

The MSI installer will be published through GitHub Releases once the package is built and tested.

## 🛠️ Technologies

- Python
- HTML
- PyInstaller
- WiX Toolset

## ✨ Features

- Windows Live Messenger troubleshooting
- Legacy application troubleshooting
- Installation assistance
- Classic Windows-inspired interface

## 👨‍💻 Publishers

- KrispyChickenKizoBoss
- KitKatBreak

## 📜 Project Status

WizyBoo is under development.

## 💙 Thank you!

Thank you for checking out WizyBoo!
