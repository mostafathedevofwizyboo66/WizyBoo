Core application modules will be added here.
